const NUM_SIMULACIONES = 2000;

let partidasGanadas = 0;
let partidasPerdidas = 0;
let puntuacionesGanadas = [];
let puntuacionesPerdidas = [];
let numCartasGanadas = [];
let numCartasPerdidas = [];

class JuegoSieteYMedia {
    constructor() {
        this.baraja = new Baraja();
        this.baraja.barajar();
    }

    jugarPartida() {
        let mano = [];
        let puntuacion = 0;

        while (puntuacion < 7.5) {
            const carta = this.baraja.getCartas().pop();
            mano.push(carta);
            puntuacion += this.calcularValorCarta(carta);
        }

        if (puntuacion <= 7.5) {
            partidasGanadas++;
            puntuacionesGanadas.push(puntuacion);
            numCartasGanadas.push(mano.length);
        } else {
            partidasPerdidas++;
            puntuacionesPerdidas.push(puntuacion);
            numCartasPerdidas.push(mano.length);
        }
    }

    calcularValorCarta(carta) {
        const valorNumerico = parseInt(carta.getValor());

        if (valorNumerico >= 8) {
            return 0.5; // Cartas con valor 8, 9 y 10 valen 0.5 puntos
        } else if (valorNumerico === 1) {
            return 1; // As vale 1 punto
        } else {
            return valorNumerico; // El resto de las cartas valen su propio valor numérico
        }
    }
}

class Baraja {
    constructor() {
        this.cartas = [];
        this.inicializarBaraja();
    }

    inicializarBaraja() {
        const palos = ['Oros', 'Copas', 'Espadas', 'Bastos'];
        const valores = ['As', '2', '3', '4', '5', '6', '7', 'Sota', 'Caballo', 'Rey'];

        for (const palo of palos) {
            for (const valor of valores) {
                let carta = new Carta(valor, palo);
                this.cartas.push(carta);
            }
        }
    }

    getCartas() {
        return this.cartas;
    }

    barajar() {
        for (let i = this.cartas.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.cartas[i], this.cartas[j]] = [this.cartas[j], this.cartas[i]];
        }
    }
}

class Carta {
    constructor(valor, palo) {
        this.valor = valor;
        this.palo = palo;
    }

    getValor() {
        return this.valor;
    }
}

for (let i = 0; i < NUM_SIMULACIONES; i++) {
    const juego = new JuegoSieteYMedia();
    juego.jugarPartida();
}

console.log("Partidas ganadas:", partidasGanadas);
console.log("Partidas perdidas:", partidasPerdidas);

const ctx = document.getElementById('grafico').getContext('2d');
const grafico = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Partidas Ganadas', 'Partidas Perdidas'],
        datasets: [{
            label: 'Puntuaciones',
            data: [partidasGanadas, partidasPerdidas],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 99, 132, 0.2)',
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
                'rgba(255, 99, 132, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true, 
                    stepSize: 1 
                }
            }]
        }
    }
});
