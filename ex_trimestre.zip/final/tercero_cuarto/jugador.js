import { baraja } from "./baraja.js";

export class jugador {
    constructor() {
        this.baraja = new baraja();
        this.puntuacion = 0;
    }
    pedirPunt() {
        this.puntuacion += this.baraja.pedirCarta().valor;
    }
    
}