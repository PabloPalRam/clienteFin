import { jugador } from "./jugador.js";

document.getElementById("nuevoJug").addEventListener('click', function () {
    let nuevoJu = new jugador();
    crearTablero(nuevoJu);
});

function crearTablero(player) {
    let jugada = document.getElementById("contenido");
    jugada.innerHTML = '';

    let div = document.createElement("div");

    let button = document.createElement("button");
    button.textContent = "Pedir Carta";

    let plantarse = document.createElement("button");
    plantarse.textContent = "Plantarse";

    let timer;

    // Función para bloquear los controles si el tiempo se agota
    function bloquearControles() {
        button.disabled = true;
        plantarse.disabled = true;
        button.style.backgroundColor = "gray";
        plantarse.style.backgroundColor = "gray";
        let msj = document.createElement('h2');
        msj.textContent = "Controles bloqueados";
        div.appendChild(msj);
    }

    // Evento para pedir una carta
    button.addEventListener('click', function () {
        clearTimeout(timer); // Reiniciar temporizador
        player.pedirPunt();

        let total = document.createElement('h3');
        total.textContent = "Puntuación: " + player.puntuacion;
        div.appendChild(total);

        if (player.puntuacion > 7.5) {
            bloquearControles();
            button.style.backgroundColor = "red";
            console.log("Error. Se bloquearon los controles.");
        } else {
            timer = setTimeout(bloquearControles, 5000); // Reiniciar temporizador
        }
    });

    plantarse.addEventListener('click', function () {
        clearTimeout(timer); // Reiniciar temporizador
        button.disabled = true;
        plantarse.disabled = true;
        button.style.backgroundColor = "green";
        console.log("El jugador se plantó.");
    });

    // Iniciar temporizador de 5 segundos al cargar la página
    timer = setTimeout(bloquearControles, 5000);

    div.appendChild(plantarse);
    div.appendChild(button);
    jugada.appendChild(div);
}