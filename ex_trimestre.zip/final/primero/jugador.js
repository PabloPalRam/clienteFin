import { baraja } from "./baraja.js";

export class jugador {
    constructor() {
        this.baraja = new baraja();
        this.putuacion = 0;
    }
    pedirPunt() {
        this.putuacion += this.baraja.pedirCarta().valor;
    }
    
}