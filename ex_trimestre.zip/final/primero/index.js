import { jugador } from "./jugador.js";

for (let index = 0; index < 2000; index++) {
    let jug = new jugador();
    
    while (jug.putuacion < 5) { //hay que ponerle esto porque sino no me va a saltar
        jug.pedirPunt();

    } 
    console.log(jug.putuacion);
    if (jug.putuacion > 7.5) { 
        console.log("te pasaste");
    }

}

