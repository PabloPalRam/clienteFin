import { jugador } from "./jugador.js";

let partidasGanadas = 0;
let partidasPerdidas = 0;

for (let index = 0; index < 2000; index++) {
    let jug = new jugador();
    
    while (jug.putuacion < 5) {
        jug.pedirPunt();
    } 
    
    if (jug.putuacion <= 7.5) { 
        partidasGanadas++;
    } else {
        partidasPerdidas++;
    }
}

const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Partidas Ganadas', 'Partidas Perdidas'],
        datasets: [{
            label: 'Resultados de las Partidas',
            data: [partidasGanadas, partidasPerdidas],
            backgroundColor: [
                'rgba(75, 192, 192, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(75, 192, 192, 1)',
                'rgba(255, 99, 132, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
