export class baraja {
    constructor() {
        this.cartas = this.crearBaraja();
    }

    crearBaraja() {
        const nombresPalos = {
            1: "oros",
            2: "copas",
            3: "espadas",
            4: "bastos"
        };

        const baraja = new Array(48).fill(0).map((item, index) => {
                const numero = (index % 12) + 1;
                const palo = nombresPalos[Math.floor(index / 12) + 1];
                const valor = (numero < 9) ? numero : 0.5;
                return { numero, palo, valor };
            })
            .filter((item) => item.numero != 8 && item.numero != 9);

        return baraja;
    }

    pedirCarta() {
         const num = Math.floor(Math.random() * this.cartas.length);
         return this.cartas.splice(num, 1)[0];
    }
}